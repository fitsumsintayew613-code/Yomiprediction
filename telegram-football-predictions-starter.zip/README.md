# MatchPulse — Telegram Football Predictions Starter

A phone-friendly Next.js starter for a Telegram Mini App, Vercel deployment, Firebase Auth/Firestore, Gemini analysis drafts, and an admin-only publishing API.

## Included
- Dark mobile-first prediction UI with free/premium labels
- Firebase email/password admin sign-in
- Server-side admin verification using Firebase custom claim `admin: true`
- Admin create/publish form
- Server-side Gemini analysis draft endpoint
- Firestore rules that deny direct browser access
- Telegram Web App ready/expand integration
- Environment variable template

## Important prototype limits
- Sample fixtures are fictional placeholders.
- Telegram identity is **not yet authenticated** against server-validated `initData`. This starter uses Firebase email/password for the admin panel and can be opened as a normal web page or Telegram Mini App.
- Premium labels do not enforce payment or access control yet. Do not sell premium access until verified entitlements are implemented server-side.
- No fixture/odds provider is connected; do not present generated content as verified data.
- AdSense is not integrated by default. Obtain eligibility/approval and review policies before adding ad code.

## 1. Create services using your phone
1. Create a GitHub repository and upload these files.
2. Create a Firebase project at https://console.firebase.google.com
3. Add a Web App in Firebase project settings. Copy its config to the environment variables below.
4. Enable Authentication > Sign-in method > Email/Password. Create your own admin account.
5. Create a Cloud Firestore database. Start in production mode and publish `firestore.rules`.
6. Create a Gemini API key at https://aistudio.google.com/apikey.
7. Import the repository at https://vercel.com/new.

## 2. Vercel environment variables
Add these in Project Settings > Environment Variables for Preview and Production as appropriate:
- `NEXT_PUBLIC_FIREBASE_API_KEY`
- `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
- `NEXT_PUBLIC_FIREBASE_APP_ID`
- `GEMINI_API_KEY`
- `FIREBASE_SERVICE_ACCOUNT_JSON`

For `FIREBASE_SERVICE_ACCOUNT_JSON`, create a service account in Google Cloud/Firebase Admin settings and paste its full JSON as one environment-variable value. Treat it as a password. Never put it in GitHub or any `NEXT_PUBLIC_` variable. Restrict access to the Vercel project.

Redeploy after setting variables.

## 3. Give your account the admin claim
Use a trusted computer/terminal or a secure CI job, not a public online code runner:
1. Install Node.js and Firebase Admin SDK in a private environment.
2. Set `GOOGLE_APPLICATION_CREDENTIALS` to a service-account file outside the repository and `ADMIN_EMAIL` to your Firebase user's email.
3. Run `node scripts/set-admin.mjs`.
4. Sign out and sign back into `/admin` so Firebase refreshes the ID token.

Do not expose service-account credentials to browser JavaScript, chat messages, or a public repository.

## 4. Connect the Telegram Mini App
1. Open @BotFather, create a bot with `/newbot`.
2. Deploy the site and copy its HTTPS URL.
3. In BotFather use `/setmenubutton`, select the bot, choose a button title and set the deployed URL.
4. Open the bot in Telegram and test the menu button.

The homepage loads Telegram's WebApp object when Telegram provides it. Before relying on Telegram user identity for user accounts or entitlements, implement backend validation of the raw `Telegram.WebApp.initData` using Telegram's documented HMAC procedure and bot token. Do not trust `initDataUnsafe` or a user ID sent from the browser.

## 5. Test
- Visit `/` to see the demo UI.
- Visit `/admin` to sign in.
- Create a draft with Gemini, fact-check it, and publish.
- Reload `/` to see published Firestore predictions.
- Test in Telegram on Android and iOS.
- Check Vercel logs for server errors; never print tokens or secret environment variables.

## 6. Google ads
AdSense is not wired into this starter. First review current AdSense site approval rules and Google gambling / gambling-promoting content policies for your countries and content. Do not assume a betting-prediction site is eligible. Only add approved ad code after review; avoid ads or outbound links that violate policies. Provide privacy and contact information and any legally required age/responsible-gambling notices.

## Production checklist
- [ ] Implement Telegram `initData` validation on the server if using Telegram identity.
- [ ] Restrict admin routes with Firebase custom claims (already included).
- [ ] Keep Firestore browser rules deny-by-default (included).
- [ ] Add rate limiting and abuse monitoring to AI endpoint.
- [ ] Add server-side premium entitlement checks before exposing premium analysis.
- [ ] Connect a licensed/authorized fixture and odds data source if needed.
- [ ] Add privacy policy, terms, contact details, and applicable disclaimers.
- [ ] Review local law, Telegram policies, and advertising network eligibility.
- [ ] Use a staging deployment before publishing widely.

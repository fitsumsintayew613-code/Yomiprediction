// Run locally or in a trusted private environment after setting:
// GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
// ADMIN_EMAIL=you@example.com
// Never commit a service-account JSON file.
import admin from "firebase-admin";
admin.initializeApp({credential: admin.credential.applicationDefault()});
const email = process.env.ADMIN_EMAIL;
if (!email) throw new Error("Set ADMIN_EMAIL.");
const user = await admin.auth().getUserByEmail(email);
await admin.auth().setCustomUserClaims(user.uid, {admin:true});
console.log(`Admin claim set for ${email}. Sign out and sign back in to refresh the token.`);
process.exit(0);

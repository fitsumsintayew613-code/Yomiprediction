import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";

const config = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

export const firebaseReady = Boolean(config.apiKey && config.projectId && config.appId);
const app = getApps().length ? getApps()[0] : initializeApp({
  apiKey: config.apiKey || "demo-key",
  authDomain: config.authDomain || "demo.invalid",
  projectId: config.projectId || "demo-project",
  appId: config.appId || "demo-app"
});
export const auth = getAuth(app);

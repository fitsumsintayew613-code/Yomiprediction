import { NextRequest } from "next/server";
import { adminAuth } from "@/lib/firebase-admin";

export async function requireAdmin(request: NextRequest) {
  const header = request.headers.get("authorization") || "";
  if (!header.startsWith("Bearer ")) throw new Error("Sign in as an admin first.");
  const token = header.slice(7);
  const decoded = await adminAuth().verifyIdToken(token);
  if (decoded.admin !== true) throw new Error("Admin permission required.");
  return decoded;
}

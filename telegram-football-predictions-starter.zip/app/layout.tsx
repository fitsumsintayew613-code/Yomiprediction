import type { Metadata, Viewport } from "next";
import "./globals.css";
import Script from "next/script";

export const metadata: Metadata = {
  title: "MatchPulse | Football Predictions",
  description: "Football match analysis and prediction insights.",
  applicationName: "MatchPulse"
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#090d12"
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><Script src="https://telegram.org/js/telegram-web-app.js?64" strategy="beforeInteractive" />{children}</body></html>;
}

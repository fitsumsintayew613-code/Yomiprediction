import { NextRequest, NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/require-admin";
export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAdmin(request);
    const body = await request.json();
    const fields = ["home","away","league","kickoff","market","analysis"];
    for (const field of fields) {
      if (typeof body[field] !== "string" || !body[field].trim() || body[field].length > 4000) {
        return NextResponse.json({error:`Invalid ${field}`},{status:400});
      }
    }
    if (!["free","premium"].includes(body.tier)) return NextResponse.json({error:"Invalid tier"},{status:400});
    const doc = {
      home:body.home.trim(), away:body.away.trim(), league:body.league.trim(),
      kickoff:body.kickoff.trim(), market:body.market.trim(),
      odds:typeof body.odds==="string"?body.odds.slice(0,50):"",
      tier:body.tier, analysis:body.analysis.trim(), published:body.published===true,
      createdBy:user.uid, createdAt:new Date().toISOString()
    };
    const ref = await adminDb().collection("predictions").add(doc);
    return NextResponse.json({id:ref.id});
  } catch(e) {
    return NextResponse.json({error:e instanceof Error?e.message:"Unauthorized"},{status:401});
  }
}

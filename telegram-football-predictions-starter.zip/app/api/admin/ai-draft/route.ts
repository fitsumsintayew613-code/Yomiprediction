import { NextRequest, NextResponse } from "next/server";
import { GoogleGenAI } from "@google/genai";
import { requireAdmin } from "@/lib/require-admin";
export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    await requireAdmin(request);
    if (!process.env.GEMINI_API_KEY) return NextResponse.json({error:"GEMINI_API_KEY is not configured."},{status:503});
    const body=await request.json();
    const home=String(body.home||"").slice(0,100), away=String(body.away||"").slice(0,100);
    const league=String(body.league||"").slice(0,100), market=String(body.market||"").slice(0,200);
    if(!home||!away||!league||!market) return NextResponse.json({error:"Enter both teams, league and market first."},{status:400});
    const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
    const response=await ai.models.generateContent({
      model:"gemini-2.5-flash",
      contents:`Write a concise, cautious football match-analysis DRAFT for an admin to review.
Match: ${home} vs ${away}; league: ${league}; proposed market: ${market}.
No live data was supplied. Do NOT invent current form, injuries, lineups, odds, statistics, or claim to know the result.
Explicitly state that team-specific facts need verification. Discuss only general factors an editor should check and uncertainty. Do not guarantee outcomes or encourage risky gambling. Return plain text, max 180 words.`
    });
    return NextResponse.json({analysis:response.text||"No draft returned. Try again."});
  } catch(e) {
    return NextResponse.json({error:e instanceof Error?e.message:"AI draft failed."},{status:401});
  }
}

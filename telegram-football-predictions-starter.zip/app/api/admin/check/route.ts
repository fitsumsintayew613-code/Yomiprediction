import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/require-admin";
export const runtime = "nodejs";
export async function GET(request: NextRequest) {
  try { await requireAdmin(request); return NextResponse.json({ok:true}); }
  catch (e) { return NextResponse.json({error:e instanceof Error?e.message:"Unauthorized"},{status:401}); }
}

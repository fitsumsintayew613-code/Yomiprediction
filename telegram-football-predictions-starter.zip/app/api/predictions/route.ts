import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase-admin";

export const runtime = "nodejs";
export async function GET() {
  try {
    const snap = await adminDb().collection("predictions").where("published","==",true).get();
    const predictions = snap.docs.map(d=>({id:d.id,...d.data()}));
    predictions.sort((a:any,b:any)=>String(a.kickoff||"").localeCompare(String(b.kickoff||"")));
    return NextResponse.json({predictions});
  } catch {
    // Public demo mode is handled by the client. Do not expose database errors or credentials.
    return NextResponse.json({predictions:[]});
  }
}

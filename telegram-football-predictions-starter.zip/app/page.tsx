"use client";
import { useEffect, useState } from "react";

type Prediction = {
  id: string; home: string; away: string; league: string; kickoff: string;
  market: string; odds: string; tier: "free" | "premium"; analysis: string;
};
const demo: Prediction[] = [
  { id:"demo-1", home:"North City", away:"Harbor FC", league:"Sample League", kickoff:"Demo fixture", market:"Both teams to score", odds:"1.75", tier:"free", analysis:"Example content only. Replace with verified fixture data and your own analysis." },
  { id:"demo-2", home:"Royal Athletic", away:"United Borough", league:"Sample League", kickoff:"Demo fixture", market:"Over 1.5 goals", odds:"1.42", tier:"premium", analysis:"Premium example. Publish only after checking match information and your prediction." }
];
declare global { interface Window { Telegram?: { WebApp?: { ready:()=>void; expand:()=>void; initData?:string } } } }
export default function Home() {
  const [tab,setTab] = useState<"all"|"free"|"premium">("all");
  const [items,setItems] = useState<Prediction[]>(demo);
  useEffect(() => {
    window.Telegram?.WebApp?.ready();
    window.Telegram?.WebApp?.expand();
    fetch("/api/predictions").then(r=>r.ok?r.json():null).then(data=>{
      if (Array.isArray(data?.predictions)) setItems(data.predictions);
    }).catch(()=>{});
  },[]);
  const visible = items.filter(p=>tab==="all" || p.tier===tab);
  return <main className="shell">
    <header className="top"><div className="brand">MATCH<span>PULSE</span></div><div className="pill">⚽ FOOTBALL INSIGHTS</div></header>
    <section className="hero"><div className="eyebrow">Matchday intelligence</div><h1>Read the game.<br/>Know the numbers.</h1><p className="muted">Football match previews, prediction ideas and analysis in one place.</p><div className="meta"><span className="tag green">AI-assisted analysis</span><span className="tag">Admin-reviewed posts</span></div></section>
    <div className="row"><h2 className="section-title">Predictions</h2><span className="pill">{items.length} posts</span></div>
    <nav className="tabs">{(["all","free","premium"] as const).map(t=><button key={t} onClick={()=>setTab(t)} className={`tab ${tab===t?"active":""}`}>{t==="all"?"All picks":t==="free"?"Free":"Premium"}</button>)}</nav>
    <section className="cards">{visible.map(p=><article className="card" key={p.id}>
      <div className="row"><span className="league">{p.league}</span><span className={`tag ${p.tier==="premium"?"gold":"green"}`}>{p.tier==="premium"?"✦ PREMIUM":"FREE"}</span></div>
      <div className="teams">{p.home} <span className="muted">vs</span> {p.away}</div><div className="league">{p.kickoff}</div>
      <div className="meta"><span className="tag">{p.market}</span><span className="tag">Odds: {p.odds || "—"}</span></div>
      <p className="muted">{p.tier==="premium"?"Premium preview access is not yet connected.":p.analysis}</p>
    </article>)}</section>
    <aside className="notice">Predictions are uncertain, not guarantees. Odds can change. This app does not accept bets or handle wagering funds. Adults only; please use responsible judgment.</aside>
    <footer className="footer">MatchPulse is an informational prototype. Sample fixtures are fictional. Verify all real fixtures, odds, rights and local requirements before publishing. Advertising appears only after approval and compliant integration.</footer>
  </main>;
}

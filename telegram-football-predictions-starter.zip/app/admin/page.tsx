"use client";
import { useState } from "react";
import { signInWithEmailAndPassword, signOut } from "firebase/auth";
import { auth, firebaseReady } from "@/lib/firebase-client";

export default function AdminPage() {
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [message,setMessage] = useState("");
  const [token,setToken] = useState("");
  const [home,setHome] = useState("");
  const [away,setAway] = useState("");
  const [league,setLeague] = useState("");
  const [kickoff,setKickoff] = useState("");
  const [market,setMarket] = useState("");
  const [odds,setOdds] = useState("");
  const [tier,setTier] = useState<"free"|"premium">("free");
  const [analysis,setAnalysis] = useState("");
  const [busy,setBusy] = useState(false);

  async function login(e: React.FormEvent) {
    e.preventDefault(); setMessage("");
    try {
      if(!firebaseReady) throw new Error("Add Firebase web config to your environment first.");
      const result = await signInWithEmailAndPassword(auth,email,password);
      const idToken = await result.user.getIdToken(true);
      const check = await fetch("/api/admin/check",{headers:{Authorization:`Bearer ${idToken}`}});
      if(!check.ok) throw new Error((await check.json()).error || "This account is not an admin.");
      setToken(idToken); setMessage("Admin signed in.");
    } catch(err) { setMessage(err instanceof Error?err.message:"Sign-in failed."); }
  }
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const res=await fetch("/api/admin/predictions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${token}`},body:JSON.stringify({home,away,league,kickoff,market,odds,tier,analysis,published:true})});
      const data=await res.json(); if(!res.ok) throw new Error(data.error||"Could not publish.");
      setMessage("Prediction published."); setHome("");setAway("");setLeague("");setKickoff("");setMarket("");setOdds("");setAnalysis("");
    } catch(err) {setMessage(err instanceof Error?err.message:"Could not publish.");}
    finally {setBusy(false);}
  }
  async function draft() {
    setBusy(true); setMessage("");
    try {
      const res=await fetch("/api/admin/ai-draft",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${token}`},body:JSON.stringify({home,away,league,market})});
      const data=await res.json(); if(!res.ok) throw new Error(data.error||"AI draft failed.");
      setAnalysis(data.analysis); setMessage("AI draft ready. Review it before publishing.");
    } catch(err) {setMessage(err instanceof Error?err.message:"AI draft failed.");}
    finally {setBusy(false);}
  }
  return <main className="shell"><header className="top"><a className="brand" href="/">MATCH<span>PULSE</span></a><span className="pill">ADMIN PANEL</span></header>
    <section className="hero"><div className="eyebrow">Private workspace</div><h1>Manage your posts.</h1><p className="muted">Only Firebase accounts with a verified admin claim can publish.</p></section>
    {!token ? <form className="card form" onSubmit={login}><h2>Admin sign in</h2><label>Email</label><input className="field" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><label>Password</label><input className="field" type="password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn primary" type="submit">Sign in</button></form> :
    <><form className="card form" onSubmit={save}><h2>New prediction</h2>
      <label>Home team</label><input className="field" value={home} onChange={e=>setHome(e.target.value)} required/>
      <label>Away team</label><input className="field" value={away} onChange={e=>setAway(e.target.value)} required/>
      <label>League</label><input className="field" value={league} onChange={e=>setLeague(e.target.value)} required/>
      <label>Kickoff date/time (include timezone)</label><input className="field" value={kickoff} onChange={e=>setKickoff(e.target.value)} placeholder="e.g. 2026-11-01 18:00 UTC" required/>
      <label>Prediction market</label><input className="field" value={market} onChange={e=>setMarket(e.target.value)} required/>
      <label>Odds (optional; show source/time where appropriate)</label><input className="field" value={odds} onChange={e=>setOdds(e.target.value)}/>
      <label>Access level</label><select className="field" value={tier} onChange={e=>setTier(e.target.value as "free"|"premium")}><option value="free">Free</option><option value="premium">Premium</option></select>
      <label>Analysis (review AI output before publishing)</label><textarea className="field" rows={5} value={analysis} onChange={e=>setAnalysis(e.target.value)} required/>
      <button className="btn" type="button" onClick={draft} disabled={busy}>Draft with Gemini</button><button className="btn primary" type="submit" disabled={busy}>{busy?"Working…":"Publish prediction"}</button>
    </form><button className="btn" style={{marginTop:12}} onClick={async()=>{await signOut(auth);setToken("");setMessage("Signed out.");}}>Sign out</button></>}
    {message && <p className="notice" role="status">{message}</p>}
    <p className="footer">Do not publish invented fixtures, odds or AI claims as verified facts. Premium gating is a UI placeholder until you implement a verified entitlement/payment system.</p>
  </main>;
}
